$scriptDirectory = $PSScriptRoot

start "" /D $scriptDirectory
python3 exec.py