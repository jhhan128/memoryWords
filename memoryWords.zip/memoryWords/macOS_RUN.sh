script_directory=$(dirname $0:A)

python3 $script_directory/exec.py